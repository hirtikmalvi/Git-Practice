export enum Department {
  Engineering = "Engineering",
  HR = "HR",
  Sales = "Sales",
}
